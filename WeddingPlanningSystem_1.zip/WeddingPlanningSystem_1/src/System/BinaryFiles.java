
package System;
import Users.WeddingPlanner;
import java.io.*;
import java.util.ArrayList;



public class BinaryFiles implements Serializable {
    
    
    public static void writeInFile (String path, Object o) throws FileNotFoundException, IOException
    {
        ObjectOutputStream out = (new ObjectOutputStream (new FileOutputStream("items.bin")));
        out.writeObject(o);
        out.close();
    }
    
   public static Object readFromFile (String path)
   {        
       Object obj = null;

       try {
            ObjectInputStream in = (new ObjectInputStream (new FileInputStream ("items.bin")));
            
            obj = in.readObject();
            
            in.close();
       
        } catch (Exception e) {
            
            e.printStackTrace();
            return false;
        }
        return obj;
        
    }

   }
 
