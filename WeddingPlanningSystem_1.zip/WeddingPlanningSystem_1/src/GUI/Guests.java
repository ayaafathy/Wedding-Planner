
package GUI;
import java.awt.*;
import javax.swing.*;

public class Guests extends JFrame {

    
    
    public Guests() {
        
        setSize (300,400);
        setTitle("Guests");
        
    }
    
    
}
