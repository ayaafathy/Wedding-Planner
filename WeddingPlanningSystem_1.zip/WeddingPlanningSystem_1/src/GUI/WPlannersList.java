
package GUI;
import java.awt.*;
import static java.awt.Font.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class WPlannersList extends JFrame {

    String s1,s2,s3,s4,s5,s6;
    
    public WPlannersList() {
        setLayout(null);
        setSize (800,800);
        setTitle("Wedding Planners");
        JLabel wp = new JLabel("Choose WeddingPlanner");
        JButton Continue = new JButton("Continue");
        s1="Maryam Omar";
        s2="Reem David";
        s3="Yasser Salah";
        s4="Ahmed Fouad";
        s5="Jack Sam";
        s6= "Mark Safwat";
            JComboBox WeddingPlanners = new JComboBox (new String []{s1,s2,s3,s4,s5,s6});
            
            
            wp.setBounds(50, 50, 300, 30);
            WeddingPlanners.setBounds(250, 50, 300, 30);
            Continue.setBounds(300, 300, 300, 30);
            add(wp);
            add(WeddingPlanners);
            add(Continue);
        
    }
    

  
    
    private class continueButtonWatcher implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            
           
        }

    

    
}
}
