
package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class PositionFrame extends JFrame {
    
    JRadioButton button1, button2, button3;
    ButtonGroup posGroup;
    //SignupForm s= new SignupForm();
    //Loginform l=new Loginform();
    LoginORSignup LS = new LoginORSignup();
   // WPRegisteration wr = new WPRegisteration();
   // clRegisteration cr = new clRegisteration();
    
    public PositionFrame (){
        
    setSize (350,350);
    setTitle ("Welcome");
    Container c = getContentPane();
    c.setLayout(new GridLayout(8,0));   
    JLabel label = new JLabel ("Please chose your identity : ");
    button1 = new JRadioButton("Admin", false); 
    button2 = new JRadioButton("Wedding Planner", false);
    button3 = new JRadioButton("Client", false);
  
    
    posGroup = new ButtonGroup();
    posGroup.add(button1);
    posGroup.add(button2);
    posGroup.add(button3);
     c.add(label);
    c.add(button1);
    c.add(button2);
    c.add(button3);
button1.addActionListener(new  AcListenerbut1 ());
button2.addActionListener(new  AcListenerbut2 ());
button3.addActionListener(new  AcListenerbut3 ());

    
}

public class AcListenerbut1 implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
   
               LS.setVisible(true);
           
         
        }    
    
}
public class AcListenerbut2 implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
             LS.setVisible(true);
        }
    
}
        public class AcListenerbut3 implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            LS.setVisible(true);
        }
            
        }

}