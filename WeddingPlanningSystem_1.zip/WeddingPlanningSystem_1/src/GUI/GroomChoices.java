
package GUI;
import java.awt.*;
import javax.swing.*;

public class GroomChoices extends JFrame  {

    JLabel barbers;
    JList bList;
    String s1,s2,s3,s4,s5,s6,s7,s8,s9;
   
   
    public GroomChoices() {
    s1= "Mohamed el soghayar";
    s2="Hany Rabea";
    s3="Men In Style";
     
    JComboBox cb=new JComboBox(new String []{s1,s2,s3,s4});
    setSize (300,250);
    setTitle ("Groom Care");
    Container c = getContentPane();
    c.setLayout(new GridLayout(2,2));

    barbers = new JLabel ("Barbers:");
    
    c.add (barbers);
    c.add(cb);
    
    }   
}
