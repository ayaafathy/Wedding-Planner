
package weddplanningsystem;
import GUI.*;
import Users.*;
import WeddVendors.*;
import WeddVendors.Entertainment.*;
import WeddVendors.Beauty.*;
import WeddVendors.Decorations.*;
import WeddPayments.*;
import System.*;
import java.io.*;
import java.util.*;
import javax.swing.JFrame;

public class WeddPlanningSystem implements Serializable{
   
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
        
        
//        
//        Admin Lily = new Admin();
//        Lily.setUserEmail("Lily Maged");
//        Lily.setUsername("lily");
//        Lily.setUserEmail("lily@gmail.com");
//        Lily.setUserID("101");
//        Lily.setUserPassword("25256");
//        Lily.add();
//        
        PositionFrame pf = new PositionFrame();
        pf.setVisible(true);
        pf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Coupleinfo ci = new Coupleinfo();
        ci.setVisible(true);
////        
//        clRegisteration c = new clRegisteration();
//        c.setVisible(true);
//        
//        WeddData wd = new WeddData ();
//        wd.setVisible(true);
//        
//        SigninForm signin = new SigninForm();
//        signin.setVisible(true);
//        
//        EntList ent = new EntList ();
//        ent.setVisible(true);
//        
//        BrideChoices bride = new BrideChoices ();
//        bride.setVisible(true);
//        
//        GroomChoices groom = new GroomChoices();
//        groom.setVisible(true);
        
//         MainMenu menu = new MainMenu();
//         menu.setVisible(true);
//         menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//     
//         Organizer o = new Organizer();
//         o.setVisible(true);

//         Planner p = new Planner();
//         p.setVisible(true);

//        WeddData wd = new WeddData ();
//        wd.setVisible(true);
        
//        WPRegisteration wr = new WPRegisteration();
//        wr.setVisible(true);


        

//    System.out.println("***Guide:\n  1.Admin:\n  2.Wedding Planner:\n  3.Client\n");  
//    Scanner PosScanner = new Scanner(System.in);
//     int pos = PosScanner.nextInt();
//        switch (pos)
//        {
//            case 1:
//         {
//       
//         Admin a = new Admin();
//         
//           break;
//           
//         }
//          
//         case 2:
//             
//          WeddingPlanner wp = new WeddingPlanner();
//          System.out.println("***Guide:\n  a.Register:\n  b.login:\n ");  
//          Scanner keyScanner2 = new Scanner(System.in);
//          String key2 = keyScanner2.nextLine();
//              switch (key2)
//
//            {
//             case "a":
//                 {    
//    
//         System.out.println("Full Name:");
//         Scanner wpn = new Scanner(System.in);
//         wp.setUserFullName(wpn.next());
//         
//         System.out.println("Email Address:");
//         Scanner wpe = new Scanner(System.in);
//         wp.setUserEmail(wpe.next());
//         
//         System.out.println("Phone Number:");
//         Scanner wpp = new Scanner(System.in);
//         wp.setWpPhoneNumber(wpp.next());
//         
//         System.out.println("ID:");
//         Scanner wpid = new Scanner(System.in);
//         wp.setUserPassword(wpid.next()); 
//         
//         System.out.println("Enter a new username:");
//         Scanner wpu = new Scanner(System.in);
//         wp.setUsername(wpu.next());
//         
//         System.out.println("Enter a new password:");
//         Scanner wpps = new Scanner(System.in);
//         wp.setUserPassword(wpps.next()); 
//         
//         System.out.println("Availability:");
//         Scanner wpa = new Scanner(System.in);
//         wp.setAvailability(wpa.nextBoolean());
//         
//         System.out.println("salary:");
//         Scanner wps = new Scanner(System.in);
//         wp.setUserPassword(wps.next()); 
//         
//         wp.add();
//           break;
//              }
//                 
//         case "b":
//         {
//          break;
//              }  
//          }
//           
//         case 3:
//             
//          Client cl = new Client ();
//          System.out.println("***Guide:\n  a.Register:\n  b.login:\n ");  
//          Scanner keyScanner3 = new Scanner(System.in);
//          String key3 = keyScanner3.nextLine();
//              switch (key3)
//            {
//             case "a":
//             { 
//        
//         
//         System.out.println("Full Name:");
//         Scanner cln = new Scanner(System.in);
//         cl.setUserFullName(cln.next());
//              
//         System.out.println("Email Address:");
//         Scanner cle = new Scanner(System.in);
//         cl.setUserEmail(cle.next());
// 
//         System.out.println("Phone Number:");
//         Scanner clp = new Scanner(System.in);
//         cl.setPhoneNumber(clp.next());
//         
//         System.out.println("ID:");
//         Scanner clid = new Scanner(System.in);
//         cl.setUserPassword(clid.next()); 
//         
//         System.out.println("Enter a new username:");
//         Scanner clu = new Scanner(System.in);
//         cl.setUsername(clu.next());
//         
//         System.out.println("Enter a new password:");
//         Scanner clps = new Scanner(System.in);
//         cl.setUserPassword(clps.next()); 
//         
//         System.out.println("Budget:");
//         Scanner clbud = new Scanner(System.in);
//         cl.setPhoneNumber(clbud.next());
//         
//         cl.add();
//        
//         break;
//             }
//             
//         case "b":
//             {
//         break;
//             }
//        } 
//     }   
//
//
//     

//  Client Mai = new Client ();
//  Mai.setUserEmail("Mai Adham");
//  Mai.setUsername("mai");
//  Mai.setUserEmail("mai@gmail.com");
//  Mai.setUserID("8");
//  Mai.setUserPassword("21258");
//  Mai.setBudget(20000.700);
//  Mai.add();
//        
//
//   Videography Jane = new Videography();
//   Jane.setVideographerSalary(1200);
//   Jane.setVideoTheme("Classic");
//   Jane.setName("Jane Akram");
//   Jane.setID("113");
//   Jane.setWebsite("www.janeslides.com");
//   Jane.setPhoneNumber("0111723126");
//   Jane.add();
//        
//   Videography Sara = new Videography();
//   Sara.setVideographerSalary(1200);
//   Sara.setVideoTheme("Classic");
//   Sara.setName("Sara Ahmed");
//   Sara.setID("114");
//   Sara.setWebsite("www.saraslides.com");
//   Sara.setPhoneNumber("0111728826");
//   Sara.add();
//     
//   Officiant Mahmoud = new Officiant();
//   Mahmoud.setOffSalary(160.0);
//   Mahmoud.setWebsite("Muslim");
//   Mahmoud.setName("Mahmoud ElDin");
//   Mahmoud.setWebsite("");
//   Mahmoud.setPhoneNumber("0100235856");
//   Mahmoud.setID("001");
//   Mahmoud.add( );
//        
//   Officiant George = new Officiant();
//   George.setOffSalary(165.0);
//   George.setWebsite("Christian");
//   George.setName("George Botros");
//   George.setWebsite("");
//   George.setPhoneNumber("01230023586");
//   George.setID("002");
//   George.add( );
//        
//   Transportation Car1=new Transportation();
//   Car1.setCarCost("1500");
//   Car1.setCarID("202");
//   Car1.setCarType("Limo");
//   Car1.add();
//    
//   Transportation car2  =new Transportation();
//   car2.setCarCost("2000");
//   car2.setCarID("303");
//   car2.setCarType("Mercedes");
//   car2.add();
// 
//    Barber ManHairCut =new Barber();
//    ManHairCut.setSalary(500);
//    ManHairCut.add();
//        
//   Beautician WomanMakeup =new Beautician();
//   WomanMakeup.setSalary(550);
//   WomanMakeup.add();
//    
//   Hairdresser WomanWig=new Hairdresser();
//   WomanWig.setSalary(6000);
//   WomanWig.add();
//    
//   DJ Sasa = new DJ();
//   Sasa.setDjSalary(2000.0);
//// Sasa.setPlaylist(playlist.add("mehzo")) ;
//   Sasa.setName("Sasa.Remix");
//   Sasa.setID("567");
//   Sasa.setWebsite("www.sasaremix4711.com");
//   Sasa.setPhoneNumber("0111623126");
//   Sasa.add();
//        
//   DJ Tiesto = new DJ();
//   Tiesto.setDjSalary(2500.0);
//// Tiesto.setPlaylist(playlist.add("mehzo")) ;
//   Tiesto.setName("Tiesto Biko");
//   Tiesto.setID("568");
//   Tiesto.setWebsite("www.tiestodj.com");
//   Tiesto.setPhoneNumber("011178226");
//   Tiesto.add();
//        
//   Photography Ramy = new Photography();
//   Ramy.setPhotographySalary(2500.0);
//   Ramy.setPhotosTheme("Classic");
//   Ramy.setName("Ramy Fayez");
//   Ramy.setID("111");
//   Ramy.setWebsite("www.ramyphotots.com");
//   Ramy.setPhoneNumber("0111623126");
//   Ramy.add();
//        
//   Photography Joe = new Photography();
//   Joe.setPhotographySalary(2500.0);
//   Joe.setPhotosTheme("Classic");
//   Joe.setName("Youssef Ahmed");
//   Joe.setID("121");
//   Joe.setWebsite("www.joeypics.com");
//   Joe.setPhoneNumber("010045726");
//   Joe.add();
//        
//   Florists flowers = new Florists();
//   flowers.setFlowers("Lillies");
//   flowers.add();
//    
//    Theme theme1 = new Theme();
//    theme1.setThemeStyle("FairyTale");
//    theme1.add();
//        
    
  
    } 
}
