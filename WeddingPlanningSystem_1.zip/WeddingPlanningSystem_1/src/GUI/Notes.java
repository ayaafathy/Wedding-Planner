
package GUI;
import java.awt.*;
import static java.awt.Font.*;
import javax.swing.*;


public class Notes extends JFrame {

    
    
    public Notes() {
        
    }
    
    
}
