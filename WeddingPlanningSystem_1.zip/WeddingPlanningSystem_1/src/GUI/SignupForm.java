
package GUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import javax.swing.*;

public class SignupForm extends JFrame {
    
   /* JLabel userLabel;
    JTextField userText;
    JLabel passwordLabel;
    JPasswordField passwordText;
    JButton loginButton;
    JButton registerButton;       
            
    public SignupForm (){
    
      /*setSize (350 , 170);
      setTitle ("Signin");
      Container c = getContentPane();
      c.setLayout(null);
        
      userLabel = new JLabel("Username");
      passwordLabel = new JLabel("Password");
      userText = new JTextField(20);
      passwordText = new JPasswordField(20);
      loginButton = new JButton("Signin");
      registerButton = new JButton("Register");

      userLabel.setBounds(10, 10, 80, 25);
      passwordLabel.setBounds(10, 40, 80, 25);
      userText.setBounds(100, 10, 160, 25);
      passwordText.setBounds(100, 40, 160, 25);
      loginButton.setBounds(10, 80, 80, 25);
      registerButton.setBounds(170, 80, 90, 25);
      
      c.add(userLabel);
      c.add(passwordLabel);
      c.add(userText);
      c.add(passwordText);
      c.add(loginButton);
      c.add(registerButton);

}*/
protected Loginform log=new Loginform();
JLabel lblName = new JLabel(" Please fill the following information : ");
   
JLabel firstNameLabel;
    JTextField firstName;

    JLabel lastNameLabel;
    JTextField lastName;

    JLabel usernameLabel;
    JTextField username;

    JLabel passwordLabel;
    JPasswordField passwordField;

    JLabel emailLabel;
    JTextField emailField;

    JLabel phoneNumberLabel;
    JTextField phoneNumber;

    JTextField dateOfBirth;
    JLabel dateOfBirthLabel;

    JTextField day;
    JLabel dayLabel;
    JTextField month;
    JLabel monthLabel;
    JTextField year;
    JLabel yearLabel;

    JLabel genderLabel;
    JRadioButton malegender;
    JRadioButton femalegender;
    ButtonGroup gendergroup;
    
    JLabel positionLabel;
    JComboBox positionsBox;
    JButton submit;
  
 
   
   
public SignupForm (){
    firstNameLabel = new JLabel("First Name");
        firstName = new JTextField();

        lastNameLabel = new JLabel("Last Name");
        lastName = new JTextField();

        usernameLabel = new JLabel("Username");
        username = new JTextField();

        passwordLabel = new JLabel("Password");
        passwordField = new JPasswordField();

        emailLabel = new JLabel("Email");
        emailField = new JTextField();

        phoneNumberLabel = new JLabel("Phone Number");
        phoneNumber = new JTextField("");

        dateOfBirthLabel = new JLabel("Date of Birth");
        day = new JTextField();
        day.setToolTipText("Day");
        month = new JTextField();
        year = new JTextField();
        malegender = new JRadioButton("Male");
        femalegender = new JRadioButton("Female");
        
        genderLabel = new JLabel("Gender");
       
        gendergroup = new ButtonGroup();
        gendergroup.add(malegender);
        gendergroup.add(femalegender);
        
        submit = new JButton("Register");

        setLayout(null);
        firstNameLabel.setBounds(50, 50, 300, 30);
        firstName.setBounds(200, 50, 300, 30);

        lastNameLabel.setBounds(50, 100, 300, 30);
        lastName.setBounds(200, 100, 300, 30);

        usernameLabel.setBounds(50, 150, 300, 30);
        username.setBounds(200, 150, 300, 30);

        passwordLabel.setBounds(50, 200, 300, 30);
        passwordField.setBounds(200, 200, 300, 30);
        passwordField.setEchoChar('*');

        emailLabel.setBounds(50, 250, 300, 30);
        emailField.setBounds(200, 250, 300, 30);

        phoneNumberLabel.setBounds(50, 300, 300, 30);
        phoneNumber.setBounds(200, 300, 300, 30);

        dateOfBirthLabel.setBounds(50, 350, 100, 30);
        day.setBounds(200, 350, 80, 30);
        month.setBounds(150, 330, 50, 50);
        month.setBounds(320, 350, 80, 30);
       
        year.setBounds(420, 350, 80, 30);

        genderLabel.setBounds(50, 450, 50, 30);
       
        malegender.setBounds(150, 450, 100, 50);
        femalegender.setBounds(150, 500, 100, 50);

        submit.setBounds(400, 550, 100, 30);
       
        this.add(firstNameLabel);
        this.add(firstName);
        this.add(lastNameLabel);
        this.add(lastName);
        this.add(usernameLabel);
        this.add(username);
        this.add(passwordLabel);
        this.add(passwordField);
        this.add(emailLabel);
        this.add(emailField);
        this.add(phoneNumberLabel);
        this.add(phoneNumber);

        this.add(dateOfBirthLabel);
        this.add(day);

        this.add(month);

        this.add(year);

      
        this.add(malegender);
        this.add(femalegender);
        this.add(genderLabel);

        this.add(submit);

      
        setSize(600, 700);
        setVisible(false);
        setTitle("SignUp Form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //todo : Add action listener for the submit button and add the proper validations for each field 
     
        submit.addActionListener(new submitbuttonwatcher());
        
   /* setSize(600,600);
    setLayout(new FlowLayout());
    Container cp= getContentPane(); 
    cp.add(lblName);
   cp. add(fn);
    cp.add(fieldfn);
    cp.add(mn);
    cp.add(fieldmn);
    cp.add(ln);
    cp.add(fieldln);
    cp.add(email);
    cp.add(fielde);
    cp.add(Username);
    cp.add(fieldu);
    cp.add(Password);
    cp.add(fieldp);
    cp.add(RetypePass);
    cp.add(fieldrp);
    cp.add(nationalid);
    cp.add(fieldn);
    cp.add(mobilenumber);
    cp.add(fieldm);
    cp.add (gender);
    cp.add(gender);
    cp.add(rule);*/
    
}
private class submitbuttonwatcher implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
             
        JOptionPane.showMessageDialog(null, "Registered Succesfully");
        }
    
}

    public HashMap<String, String> getLog() {
        return log.users;
    }

    public void setLog(Loginform log) {
        this.log = log;
    }

 public void AddUser(String username,String password){
     log.users.put(username, password);  
     outFile(log.users);  
 }
public void outFile(Object o){
    
    try{
        ObjectOutputStream outFile = new ObjectOutputStream(new FileOutputStream("UsersLogInFile.bin"));       
        outFile.writeObject(o);
        outFile.close();
             }catch(IOException e){
            System.out.println(e);
            }catch(Exception e){
            System.out.println(e);    
            }
    
} 
 public boolean CheckAvailability(String username){
      HashMap<String,String> searchusers=new HashMap<String,String>();
        searchusers=log.FromFile();
     for(String name:searchusers.keySet()){
         //System.out.println(name);
         if (name.equals(username)){
               return false;
            }
        }
        return true;
 }
}
