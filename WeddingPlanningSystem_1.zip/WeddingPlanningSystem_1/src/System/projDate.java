
package System;


public class projDate {
    
    private int hour;
    private String day;
    private String month;
    private int year;

   
    public projDate(int hour, String day, String month, int year) {
        this.hour = hour;
        this.day = day;
        this.month = month;
        this.year = year;
    }
    
   public projDate() {
        this.hour = 0;
        this.day = "";
        this.month = "";
        this.year = 0;
    }
    
    
    public void setHour(int hour) {
        if (0 < hour && hour < 24)
            this.hour = hour;
    }

    public int getHour() {
        return hour;
    }

    public void setDay(String day) {
            this.day = day;
    }
    
    public String getDay() {
        return day;
    }

     public void setMonth(String month) {
        this.month = month;
    }

    public String getMonth() {
        return month;
    }

     public void setYear(int year) {
         if (0 < year && year >= 2018)
        this.year = year;
    }

    public int getYear() {
        return year;
    }
    
//    public void modifyDate ()
//    {
//    }
    
}
