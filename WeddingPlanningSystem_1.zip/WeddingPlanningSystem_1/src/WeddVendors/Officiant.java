
package WeddVendors;

import System.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Officiant extends Vendors implements Serializable{
    
    private double offSalary;
    private String title;
    private final String path = "C:\\Users\\Aya\\Documents\\NetBeansProjects\\WeddPlanner\\BinaryFiles\\officiants.dat";


 public Officiant( ) {
        super();
        this.offSalary = 0.0;
        this.title = " ";
    }
   
   
    public Officiant(double offSalary, String title, String name, String website, String phoneNumber, String ID) {
        super(name, website, phoneNumber, ID);
        this.offSalary = offSalary;
        this.title = title;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getOffSalary() {
        return offSalary;
    }

    public void setOffSalary(double offSalary) {
        this.offSalary = offSalary;
    }

   public void add() 
    {
            ArrayList <Officiant> o = (ArrayList<Officiant>) BinaryFiles.readFromFile(path);
            if (o == null ){
                o = new ArrayList <>();}
            
            o.add(this);
        try {
            BinaryFiles.writeInFile(path, o);
        } catch (IOException ex) {
            Logger.getLogger(Officiant.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
    public boolean delelte (String id) 
    {
        try {
            ArrayList <Officiant> o = (ArrayList<Officiant>) BinaryFiles.readFromFile(path);
            int index = -1;
            
            if (o != null ){
                for ( int i = 0; i < o.size() && index == -1; i++ ){
                    Officiant obj = o.get(index);
                    if (obj.getID() == null ? id == null : obj.getID().equals(id))
                        index = i;
                }}
            if (index == -1)
                return false;
            
            o.remove(index);
            BinaryFiles.writeInFile(path, o);
            return true;
            
        } catch (IOException ex) {
            Logger.getLogger(Officiant.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }
     
   
   
}
