
package GUI;

import Users.*;
import java.awt.*;
import java.awt.event.*;
import java.io.EOFException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class WPRegisteration  extends JFrame implements Serializable{
    
     JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10;
     JTextField t1, t2, t3, t4, t5, t6, t7, t8;
     JRadioButton button1, button2, button3, button4;
     JButton b1, b2;
     ButtonGroup bg1, bg2 ;
     
     SignupForm s = new SignupForm();
     public static WeddingPlanner wp = new WeddingPlanner ();
     
     public WPRegisteration ()
     {
      setSize (620 , 670);
      setTitle ("Wedding Planner Registeration Form ");
      Container c = getContentPane();
      c.setLayout(null);

     
     l1 = new JLabel("Full Name ");
     l2 = new JLabel("Gender ");
     l3 = new JLabel("E-mail Adress ");
     l4 = new JLabel("Phone Number ");
     l5 = new JLabel("National ID ");
     l6 = new JLabel("Username ");
     l7 = new JLabel("Create a new Password ");
     l8 = new JLabel("Re-write Password ");
     l9 = new JLabel ("Salary ");
     l10 = new JLabel ("Availability ");

     l1.setBounds(50,20,200,40);
     l2.setBounds (50,70,200,40);
     l3.setBounds(50,120,200,40);
     l4.setBounds(50,170,200,40);     
     l5.setBounds(50,220,200,40);     
     l6.setBounds(50,270,200,40);
     l7.setBounds(50,320,200,40);
     l8.setBounds(50,370,200,40);
     l9.setBounds(50,420,200,40);
     l10.setBounds(50,470,200,40);

     t1 = new JTextField();
     t1.addActionListener(new AcListener());
     t2 = new JTextField();
     t2.addActionListener(new AcListener());
     t3 = new JTextField();     
     t3.addActionListener(new AcListener());
     t4 = new JTextField();     
     t4.addActionListener(new AcListener());
     t5 = new JTextField();     
     t5.addActionListener(new AcListener());
     t6 = new JPasswordField();     
     t6.addActionListener(new AcListener());
     t7 = new JPasswordField();     
     t7.addActionListener(new AcListener());
     t8 = new JTextField();     
     t8.addActionListener(new AcListener());

     button1 = new JRadioButton("Male", false); 
     button1.addActionListener(new AcListener());
     button2 = new JRadioButton("Female", false);
     button2.addActionListener(new AcListener());
     button3 = new JRadioButton ("Available", false);
     button3.addActionListener(new AcListener());
     button4 = new JRadioButton ("Not Available", false);
     button4.addActionListener(new AcListener());


     t1.setBounds(250, 20, 200, 30);
     button1.setBounds(250, 70, 100, 30);
     button2.setBounds(350, 70, 100, 30);
     t2.setBounds(250, 120, 200, 30);
     t3.setBounds(250, 170, 200, 30);
     t4.setBounds(250, 220, 200, 30);
     t5.setBounds(250, 270, 200, 30);
     t6.setBounds(250, 320, 200, 30);
     t7.setBounds(250, 370, 200, 30);
     t8.setBounds(250, 420, 200, 30);
     button3.setBounds(250, 470, 100, 30);
     button4.setBounds(350, 470, 100, 30);

     b1 = new JButton("Sign in");
     b1.addActionListener(new AcListener());
     
     b2 = new JButton("Next");
     b2.addActionListener(new AcListener());

     b1.setBounds(50, 550, 100, 40);
     b2.setBounds(350, 550, 100, 40);
     
     bg1 = new ButtonGroup();
     bg1.add(button1);
     bg1.add(button2);
     
     bg2 = new ButtonGroup();
     bg2.add(button3);
     bg2.add(button4);
     
     c.add(l1);
     c.add(l2);
     c.add(l3);
     c.add(l4);
     c.add(l5);
     c.add(l6);
     c.add(l7);
     c.add(l8);
     c.add(l9);
     c.add(l10);
     c.add(t1);
     c.add(t2);
     c.add(t3);
     c.add(t4);
     c.add(t5);
     c.add(t6);
     c.add(t7);
     c.add(t8);
     c.add(button1);
     c.add(button2);
     c.add(button3);
     c.add(button4);
     c.add(b1);
     c.add(b2);

       }
     
 public class AcListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            
            Object o = e.getSource();
           
            if (o == t1)   
              wp.setUserFullName(t1.getText());
            
            if (o == t1)   
               wp.setUserEmail(t2.getText());
            
            if (o == t1)   
               wp.setWpPhoneNumber(t3.getText());
            
            if (o == t1)   
               wp.setUserID(t4.getText());
            
            if (o == t1)   
               wp.setUsername(t5.getText());
            
            if (o == t1)   
               wp.setUserPassword(t6.getText());
            
            if (o == t1)   
               wp.setWpSalary(Integer.valueOf(t8.getText()));
            
            if (button1.isSelected())
                wp.setWpGender("Male");
            else if (button2.isSelected())
                wp.setWpGender("Female");
            
            if (button3.isSelected())
                wp.setAvailability(true);
            else if (button4.isSelected())
                wp.setAvailability(false);
                
            if (o == b1)
               s.setVisible(true);
            else if (o == b2)
            {
                try {
                    wp.add();
                } catch (EOFException ex) {
                    Logger.getLogger(WPRegisteration.class.getName()).log(Level.SEVERE, null, ex);
                }
                JOptionPane.showMessageDialog(null, "Data is saved Successfully");
               
            }    
        }
    }
}