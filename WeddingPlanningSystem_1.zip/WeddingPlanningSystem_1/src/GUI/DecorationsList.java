
package GUI;
import java.awt.*;
import static java.awt.Font.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


public class DecorationsList extends JFrame {

    JList l;
    
    public DecorationsList() {
        
       setSize (300,400);
       setTitle("Decorations");
        
    }
    
    
    
}
