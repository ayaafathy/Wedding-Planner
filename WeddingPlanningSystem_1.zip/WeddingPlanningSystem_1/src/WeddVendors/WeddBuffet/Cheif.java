
package WeddVendors.WeddBuffet;

import java.util.*;
import System.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import WeddVendors.*;



public class Cheif extends WeddVendors.Vendors implements Serializable{
    
        private double cheifSalary;
     
        private ArrayList <Cheif> Cheifs = new ArrayList <Cheif> ();
         private final String path = "C:\\Users\\Aya\\Documents\\NetBeansProjects\\WeddPlanner\\BinaryFiles\\cheif.dat";

        public Cheif() {
        super();
        this.cheifSalary = 0.0;
    } 
        

    public Cheif(double cheifSalary, String name, String website, String phoneNumber, String ID) {
        super(name, website, phoneNumber, ID);
        this.cheifSalary = cheifSalary;
    } 
        

    public double getCheifSalary() {
        return cheifSalary;
    }

    public void setCheifSalary(double cheifSalary) {
        this.cheifSalary = cheifSalary;
    }

 public void add(){
     ArrayList <Cheif> Ccook = (ArrayList<Cheif>) BinaryFiles.readFromFile(path);
            if (Ccook == null ){
                Ccook = new ArrayList <>();}
            
           Ccook.add(this);
        try {
            BinaryFiles.writeInFile(path, Ccook);
        } catch (IOException ex) {
            Logger.getLogger(Cheif.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
    public boolean delelte (String id) 
    {
        try {
            ArrayList <Cheif> Ccook = (ArrayList<Cheif>) BinaryFiles.readFromFile(path);
            int index = -1;
            
            if (Ccook != null ){
                for ( int i = 0; i < Ccook.size() && index == -1; i++ ){
                    Cheif obj = Ccook.get(index);
                    if (obj.getID() == null ? id == null : obj.getID().equals(id))
                        index = i;
                }}
            if (index == -1)
                return false;
            
            Ccook.remove(index);
            BinaryFiles.writeInFile(path, Ccook);
            return true;
            
        } catch (IOException ex) {
            Logger.getLogger(Cheif.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    
 }

}
