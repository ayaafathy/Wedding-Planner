
package WeddVendors.Entertainment;

import System.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import WeddVendors.*;

public class DJ extends Vendors implements Serializable {
    
    private double djSalary;
    private ArrayList <String> playlist = new ArrayList <String> ();
    private final String path = "C:\\Users\\Aya\\Documents\\NetBeansProjects\\WeddPlanner\\BinaryFiles\\djs.dat";

    public DJ(double djSalary, String name, String website, String phoneNumber, String ID) {
        super(name, website, phoneNumber, ID);
        this.djSalary = djSalary;
    }

    public DJ() {
        super();
        this.djSalary = 0.0;
    }
    
    public double getDjSalary() {
        return djSalary;
    }

    public void setDjSalary(double djSalary) {
        this.djSalary = djSalary;
    }

    public ArrayList<String> getPlaylist() {
        return playlist;
    }

    public void setPlaylist(ArrayList<String> playlist) {
        this.playlist = playlist;
    }
    
    public void add() {

    ArrayList <DJ> dj = (ArrayList<DJ>) BinaryFiles.readFromFile(path);
            if (dj == null ){
                dj = new ArrayList <>();}
            
           dj.add(this);
        try {
            BinaryFiles.writeInFile(path, dj);
        } catch (IOException ex) {
            Logger.getLogger(DJ.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
    public boolean delelte (String id) 
    {
        try {
            ArrayList <DJ> dj = (ArrayList<DJ>) BinaryFiles.readFromFile(path);
            int index = -1;
            
            if (dj != null ){
                for ( int i = 0; i < dj.size() && index == -1; i++ ){
                    DJ obj = dj.get(index);
                    if (obj.getID() == null ? id == null : obj.getID().equals(id))
                        index = i;
                }}
            if (index == -1)
                return false;
            
            dj.remove(index);
            BinaryFiles.writeInFile(path, dj);
            return true;
            
        } catch (IOException ex) {
            Logger.getLogger(DJ.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }
 
}

