
package weddplanningsystem;


public class Guest {
    
}
