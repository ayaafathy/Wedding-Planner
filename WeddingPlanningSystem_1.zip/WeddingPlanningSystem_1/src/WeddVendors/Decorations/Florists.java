
package WeddVendors.Decorations;

import System.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import WeddVendors.*;

     public class Florists implements Serializable {
     private String flowers;
     private final String path = "C:\\Users\\Aya\\Documents\\NetBeansProjects\\WeddPlanner\\BinaryFiles\\florist.dat";

    public Florists(String flowers) {
        this.flowers = flowers;
    }

    public Florists() {
        this.flowers="";
 }

    public String getFlowers() {
        return flowers;
    }

    public void setFlowers(String flowers) {
        this.flowers = flowers;
    }
    
    public void dispInfo(){
        System.out.println(getFlowers());
    }
    public void add(){
        ArrayList <Florists> Fflowers = (ArrayList<Florists>) BinaryFiles.readFromFile(path);
            if (Fflowers == null ){
                Fflowers = new ArrayList <>();}
            
           Fflowers.add(this);
        try {
            BinaryFiles.writeInFile(path, Fflowers);
        } catch (IOException ex) {
            Logger.getLogger(Florists.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
//    public boolean delelte (String id) 
//    {
//        try {
//            ArrayList <Florists> Vplace = (ArrayList<Florists>) BinaryFiles.readFromFile(path);
//            int index = -1;
//            
//            if (Fflowers != null ){
//                for ( int i = 0; i < Fflowers.size() && index == -1; i++ ){
//                    Florists obj = Fflowers.get(index);
//                    if (obj.getID() == null ? id == null : obj.getID().equals(id))
//                        index = i;
//                }}
//            if (index == -1)
//                return false;
//            
//            Fflowers.remove(index);
//            BinaryFiles.writeInFile(path, Fflowers);
//            return true;
//            
//        } catch (IOException ex) {
//            Logger.getLogger(Florists.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return true;
//    }
}
