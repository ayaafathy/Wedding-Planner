
package WeddPayments;


public interface IAmount {
    
    double calcTotalAmount();
}
