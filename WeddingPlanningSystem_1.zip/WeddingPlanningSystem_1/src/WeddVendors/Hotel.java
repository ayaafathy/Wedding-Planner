

package WeddVendors;
import System.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Hotel extends Vendors implements Serializable {

    private String hotelRate;
    private ArrayList <Room> rooms = new ArrayList <Room> ();
    private final String path = "C:\\Users\\Aya\\Documents\\NetBeansProjects\\WeddPlanner\\BinaryFiles\\hotels.dat";
  
    public Hotel(String hotelRate, String name, String website, String phoneNumber, String ID) {
        super(name, website, phoneNumber, ID);
        this.hotelRate = hotelRate;
    }

    public Hotel() {
        super();
        this.hotelRate = "";
    }
    
     public void add() 
    {
            ArrayList <Hotel> h = (ArrayList<Hotel>) BinaryFiles.readFromFile(path);
            if (h == null ){
                h = new ArrayList <>();}
            
            h.add(this);
        try {
            BinaryFiles.writeInFile(path, h);
        } catch (IOException ex) {
            Logger.getLogger(Hotel.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
    public boolean delelte (String id) 
    {
        try {
            ArrayList <Hotel> h = (ArrayList<Hotel>) BinaryFiles.readFromFile(path);
            int index = -1;
            
            if (h != null ){
                for ( int i = 0; i < h.size() && index == -1; i++ ){
                    Hotel obj = h.get(index);
                    if (obj.getID() == null ? id == null : obj.getID().equals(id))
                        index = i;
                }}
            if (index == -1)
                return false;
            
            h.remove(index);
            BinaryFiles.writeInFile(path, h);
            return true;
            
        } catch (IOException ex) {
            Logger.getLogger(Hotel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }
    
   
    
      
}