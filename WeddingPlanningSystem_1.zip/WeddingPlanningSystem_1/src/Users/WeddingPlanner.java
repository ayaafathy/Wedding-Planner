
package Users;

import System.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
//import javax.swing.JList;


public class WeddingPlanner extends User implements Serializable,IFile 
{
    private String wpGender;
    private boolean availability;
    private double wpSalary;
    private String wpPhoneNumber;
    private String path = "C:\\Users\\Aya\\Documents\\NetBeansProjects\\WeddPlanner\\BinaryFiles\\wplanners.dat";  
    ArrayList <WeddingPlanner> w = new ArrayList <WeddingPlanner> ();

    public WeddingPlanner(String wpGender, boolean availability, double wpSalary, String wpPhoneNumber, String userFullName, String username, String userID, String userEmail, String userPassword) {
        super(userFullName, username, userID, userEmail, userPassword);
        this.wpGender = wpGender;
        this.availability = availability;
        this.wpSalary = wpSalary;
        this.wpPhoneNumber = wpPhoneNumber;
        
    }
    
 public WeddingPlanner() {
        super();
        this.wpGender = "";
        this.availability = false;
        this.wpSalary = 0.0;
        this.wpPhoneNumber = "";

    }

    public String getWpGender() {
        return wpGender;
    }

    public void setWpGender(String wpGender) {
        this.wpGender = wpGender;
    }
  
 

    public boolean getAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }
    

    public double getWpSalary() {
        return wpSalary;
    }

    public void setWpSalary(double wpSalary) {
        this.wpSalary = wpSalary;
    }

    public String getWpPhoneNumber() {
        return wpPhoneNumber;
    }

    public void setWpPhoneNumber(String wpPhoneNumber) {
        this.wpPhoneNumber = wpPhoneNumber;
    }

     public void add  () throws EOFException
    {
            ArrayList <WeddingPlanner> w = (ArrayList<WeddingPlanner>) BinaryFiles.readFromFile(path);
            if (w == null ){
                w = new ArrayList <>();}
            
            w.add(this);
        try {
            BinaryFiles.writeInFile(path, w);
        } catch (IOException ex) {
            Logger.getLogger(WeddingPlanner.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
  
public boolean delelte (String id)
    {
        try {
            ArrayList <WeddingPlanner> w = (ArrayList<WeddingPlanner>) BinaryFiles.readFromFile(path);
            int index = -1;
            
            if (w != null ){
                for ( int i = 0; i < w.size() && index == -1; i++ ){
                    WeddingPlanner obj = w.get(index);
                    if (obj.getUserID() == null ? id == null : obj.getUserID().equals(id))
                        index = i;
                }}
            if (index == -1)
                return false;
            
            w.remove(index);
            BinaryFiles.writeInFile(path, w);
            return true;
            
        } catch (IOException ex) {
            Logger.getLogger(WeddingPlanner.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

        
public void display () {
 
   

      
}

    @Override
    public void save() {
        FileOutputStream fileOutputStream = null;
        try {
            ObjectOutputStream out = (new ObjectOutputStream (new FileOutputStream ("items.bin")));
            out.writeObject(w);
            out.close();
        } catch (IOException e) {
            
        } 
    }

    @Override
    public void load() {
        FileInputStream fileInputStream = null;
        try {
            ObjectInputStream in= (new ObjectInputStream (new FileInputStream ("items.bin")));
            w= (ArrayList<WeddingPlanner>)in.readObject();
           in.close();
           
           
        } catch (Exception e) {
            
        }
    }
    }






