/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
//import javax.swing.JLabel;

/**
 *
 * @author Rawan Khaled
 */
public class Coupleinfo extends JFrame {
   
 JLabel Bride = new JLabel (" Bride Information :");   
 JLabel BrideName = new JLabel (" Bride Full Name :"); 
 JTextField BrideNameT =new JTextField (" ");
 JLabel BrideMobileNum = new JLabel (" Bride Mobile Number :"); 
 JTextField BrideMobileNumT =new JTextField (" ");
 JLabel Bridemail = new JLabel (" Bride Email:"); 
 JTextField BridemailT =new JTextField (" ");
 JLabel Groom = new JLabel (" Groom Information :"); 
 JLabel GroomName = new JLabel (" Groom FullName :"); 
JTextField GroomNameT =new JTextField (" "); 
JLabel GroomMobileNum = new JLabel (" Groom Mobile Number :"); 
JTextField GroomMobileNumT =new JTextField (" "); 
JLabel GroomMail = new JLabel (" Groom Email:");   
JTextField GroomMailT =new JTextField (" "); 
JLabel Date = new JLabel (" Please chose the Wedding date:");
String s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec,s2018,s2019;
JLabel Budget = new JLabel ("Please Enter The Budget (in Egyption Bounds) : ");
 JTextField BudgetT   = new JTextField(" "); 
 JButton go = new JButton ("GO");
 
 public Coupleinfo (){
     setSize (800 , 900 );
     setTitle("Coupleinfo");
     setLayout(null);
     
     Bride.setBounds(50, 20, 300, 30);
     
        BrideName.setBounds(50, 50, 300, 30);
        BrideNameT.setBounds(200, 50, 300, 30);

       BrideMobileNum .setBounds(50, 100, 300, 30);
        BrideMobileNumT.setBounds(200, 100, 300, 30);

        Bridemail.setBounds(50, 150, 300, 30);
        BridemailT.setBounds(200, 150, 300, 30);

        Groom.setBounds(50, 200, 300, 30);
                
        GroomName.setBounds(50, 250, 300, 30);
       GroomNameT.setBounds(200, 250, 300, 30);
        
        GroomMobileNum.setBounds(50, 300, 300, 30);
        GroomMobileNumT.setBounds(200, 300, 300, 30);
        
        GroomMail.setBounds(50, 350, 300, 30);
        GroomMailT.setBounds(200, 350, 300, 30);
     

        Budget.setBounds(50, 500 , 300, 50);
       BudgetT.setBounds(350, 515, 300, 30);
       
       go.setBounds(50, 650, 300, 50);
        
 
     s1= "1";
     s2= "2";
     s3= "3";
     s4= "4";
     s5= "5";
     s6= "6";
     s7= "7";
     s8= "8";
     s9= "9";
     s10= "10";
     s11= "11";
     s12= "12";
     s13= "13";
     s14= "14";
     s15= "15";
     s16= "16";
     s17= "17";
     s18= "18";
     s19= "19";
     s20= "20";
     s21= "21";
     s22= "22";
     s23= "23";
     s24= "24";
     s25= "25";
     s26= "26";
     s27= "27";
     s28= "28";
     s29= "29";
     s30= "30";
     s31= "31";
     jan="January";
     feb="Feburary";
     mar="March";
     apr="April";
     may="May";
     jun="June";
     jul="July";
     aug="August";
     sep="September";
     oct="October";
     nov="November";
     dec="December";
     s2018="2018";
     s2019="2019";
     JComboBox days = new JComboBox (new String []{s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31});
     JComboBox month = new JComboBox (new String []{jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec});
     JComboBox year = new JComboBox (new String []{s2018,s2019});
 
     
        
        Date.setBounds(50, 400, 300, 50);
        days.setBounds(250, 400, 50, 50);
        month.setBounds(350, 400, 100, 50);
       
        year.setBounds(500, 400, 100, 50);

     
     add(Bride);
     add(BrideName);
        add(BrideNameT);
      add(BrideMobileNum); 
      add(  BrideMobileNumT);
        add(Bridemail);
        add(BridemailT);
        add(Groom );     
        add(GroomName);
       add(GroomNameT);
        add(GroomMobileNum);
        add(GroomMobileNumT);
        add(GroomMail);
        add(GroomMailT);
        add(Date);
        add(days);
        add(month);
        add(year);
        add(Budget);
        add(BudgetT);
       add(go);
       go.addActionListener(new gobuttonwatcher ());
     
}
  private class gobuttonwatcher implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            WPlannersList w = new WPlannersList ();
            w.setVisible(true);
            dispose();
        }
      
  }
}
