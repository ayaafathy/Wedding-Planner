
package GUI;
import java.awt.*;
import static java.awt.Font.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class OfficiantsList extends JFrame {

    JList l;
    
    
    public OfficiantsList() {
        
     setSize (300,400);
     setTitle ("Officiants");
     
    }
    
    
    
}
