
package System;

public interface IOPerations {
    
    void add();
    void delete();
    void modify();
    void search();
   
    
}
