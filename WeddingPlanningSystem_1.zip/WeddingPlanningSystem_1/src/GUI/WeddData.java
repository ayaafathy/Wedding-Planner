
package GUI;
import System.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import javax.swing.*;

public class WeddData extends JFrame implements Serializable {

    JLabel l1, l2, l3;
    JTextField t1, t2, t3, t4;
    JButton b1;
    JComboBox<Object> mm, dd;
    String [] months = {"January", "February", "March", "April","May", "June", "July", "August", "September", "October",
                        "November", "December"};
    String [] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    projDate weddDate = new projDate ();
    MainMenu m = new MainMenu();
     
     
    public WeddData() {
        
        setTitle("Complete your Profile");
        setSize(500, 400);
        this.setLayout(null);
        
        l1 = new JLabel("Partner's Full Name");
        l2 = new JLabel ("Budget");
        l3 = new JLabel ("Ceremony Date");
        
        t1 = new JTextField(" ");
        t1.addActionListener(new AcListener());
        t2 = new JTextField("00000");
        t2.addActionListener(new AcListener());
        t3 = new JTextField("24:00");
        t3.addActionListener(new AcListener());
        t4 = new JTextField("0000");
        t4.addActionListener(new AcListener());
        mm = new JComboBox(months);
        mm.addActionListener(new AcListener());
        dd = new JComboBox(days);
        dd.addActionListener(new AcListener());

       l1.setBounds(50,20,200,40);
       l2.setBounds(50,70,200,40);
       l3.setBounds(50,120,200,40);
       
       t1.setBounds(250, 20, 200, 30);
       t2.setBounds(250, 70, 200, 30);
       t3.setBounds(250, 120, 70, 30);
       t4.setBounds(350, 120, 70, 30);
       mm.setBounds(250, 170, 70, 30);
       dd.setBounds(350, 170, 70, 30);

       b1 = new JButton("Confirm");
       b1.addActionListener(new AcListener());
       b1.setBounds(180, 260, 100, 40);
     
       this.add (l1);
       this.add (l2);
       this.add (l3);
       this.add (t1);
       this.add (t2);
       this.add (t3);
       this.add (t4);
       this.add (mm);
       this.add (dd);
       this.add (b1);

     
    }
    
    public class AcListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            
            Object o = e.getSource();
           
            if (o == t1)
               clRegisteration.cl.setPartnerName(t1.getText());
            
            if (o == t2)
               clRegisteration.cl.setBudget(Integer.valueOf(t2.getText()));
            
            if (o == t3)
               weddDate.setHour(Integer.valueOf(t3.getText())); 
            
            if (o == t4)
               weddDate.setYear(Integer.valueOf(t4.getText())); 
            
            if (o == mm){
               weddDate.setMonth((String)mm.getSelectedItem());}
            
            if (o == dd){
               weddDate.setDay((String)dd.getSelectedItem());}
           
            if (o == b1)
//               clRegisteration.cl.setwDate(weddDate);
               clRegisteration.cl.add();
               m.setVisible(true);

        }
    } 
}
