
package WeddVendors.Decorations;
import System.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import WeddVendors.*;


public class Theme implements Serializable{
    private String themeStyle;
    private final String path = "C:\\Users\\Aya\\Documents\\NetBeansProjects\\WeddPlanner\\BinaryFiles\\theme.dat";

    public Theme(String themeStyle) {
        this.themeStyle = themeStyle;
    }

    public Theme() {
        this.themeStyle="";
  }

    public String getThemeStyle() {
        return themeStyle;
    }

    public void setThemeStyle(String themeStyle) {
        this.themeStyle = themeStyle;
    }

   
    
    public void dispInfo(){
        System.out.println(getThemeStyle());
    }
    public void add(){
        ArrayList <Theme> theme = (ArrayList<Theme>) BinaryFiles.readFromFile(path);
            if (theme == null ){
                theme = new ArrayList <>();}
            
           theme.add(this);
        try {
            BinaryFiles.writeInFile(path, theme);
        } catch (IOException ex) {
            Logger.getLogger(Theme.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
//    public boolean delelte (String id) 
//    {
//        try {
//            ArrayList <Theme> Vplace = (ArrayList<Theme>) BinaryFiles.readFromFile(path);
//            int index = -1;
//            
//            if (theme != null ){
//                for ( int i = 0; i < theme.size() && index == -1; i++ ){
//                    Theme obj = theme.get(index);
//                    if (obj.getID() == null ? id == null : obj.getID().equals(id))
//                        index = i;
//                }}
//            if (index == -1)
//                return false;
//            
//            theme.remove(index);
//            BinaryFiles.writeInFile(path, theme);
//            return true;
//            
//        } catch (IOException ex) {
//            Logger.getLogger(Theme.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return true;
//    }

}
