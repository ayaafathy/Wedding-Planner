
package GUI;
import java.awt.*;
import static java.awt.Font.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class BuffetList extends JFrame{

    JList l;
    
    public BuffetList() {
        
        setSize (300,400);
        setTitle("Buffet & Catering");
        
    }
    
    
    
}
